<div class="p-6 max-w-md mx-auto mt-10 bg-white rounded-xl shadow-md border border-gray-100">
    <h2 class="text-2xl font-bold mb-6 text-center">Welcome Back</h2>

    <form wire:submit.prevent="login" class="space-y-4">
        
        <div>
            <label class="block text-sm font-bold text-gray-700">Email</label>
            <input type="email" wire:model="email" class="w-full p-2 border rounded-lg bg-gray-50">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div>
            <label class="block text-sm font-bold text-gray-700">Password</label>
            <input type="password" wire:model="password" class="w-full p-2 border rounded-lg bg-gray-50">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <button type="submit" class="w-full bg-green-600 text-white py-3 rounded-lg font-bold hover:bg-green-700">
            Login
        </button>
    </form>
    
    <div class="mt-4 text-center text-sm">
        No account? <a href="/register" class="text-green-600 font-bold">Sign up here</a>
    </div>
</div><?php /**PATH C:\laragon\www\campus-eats\resources\views/livewire/auth/login.blade.php ENDPATH**/ ?>